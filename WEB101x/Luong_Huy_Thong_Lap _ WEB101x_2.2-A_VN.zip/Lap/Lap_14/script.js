alert("Hello world");
let country;
let continent;
let  polulation;
country = 'Viet Nam';
continent = 'Asia';
polulation = 100000000 + ' people';
console.log('Country: ' + country);
console.log('Continet: ' + continent);
console.log('polulation: ' + polulation);

