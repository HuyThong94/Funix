package vn.funix.fx22724.java.ASM3;

public interface ResportService {
    void log(double amount);
}
