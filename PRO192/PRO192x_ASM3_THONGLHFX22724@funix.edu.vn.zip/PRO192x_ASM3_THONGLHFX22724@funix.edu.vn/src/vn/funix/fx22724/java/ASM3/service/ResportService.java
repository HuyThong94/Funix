package vn.funix.fx22724.java.ASM3.service;

public interface ResportService {
    void log(double amount);
}
