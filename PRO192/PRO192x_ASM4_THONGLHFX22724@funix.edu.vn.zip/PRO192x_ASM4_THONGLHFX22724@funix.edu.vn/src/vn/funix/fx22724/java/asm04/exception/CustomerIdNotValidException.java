package vn.funix.fx22724.java.asm04.exception;

public class CustomerIdNotValidException {
}
