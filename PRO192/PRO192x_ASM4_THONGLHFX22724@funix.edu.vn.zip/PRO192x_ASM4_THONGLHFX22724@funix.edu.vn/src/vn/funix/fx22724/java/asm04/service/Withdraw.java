package vn.funix.fx22724.java.asm04.service;

public interface Withdraw {
    boolean withdraw(double amount);
    boolean isAccepted(double amount);
}
