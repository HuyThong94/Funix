package vn.funix.fx22724.java.asm04.common;

public class CustomerIdNotValidException extends RuntimeException {
    public CustomerIdNotValidException(String message) {
        super(message);
    }
}
